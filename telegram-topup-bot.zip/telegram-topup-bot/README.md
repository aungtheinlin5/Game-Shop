# 🎮 Telegram Game Top-Up Bot

Production-ready Telegram bot for automated game top-up ordering with payment confirmation workflow.

---

## 📁 Project Structure

```
telegram-topup-bot/
├── src/
│   ├── index.js                    ← Main entry point
│   ├── config/
│   │   └── database.js             ← MySQL pool + transaction helper
│   ├── models/
│   │   ├── Game.js                 ← Games table queries
│   │   ├── Package.js              ← Packages table queries
│   │   ├── User.js                 ← Users table + upsert
│   │   ├── Order.js                ← Order lifecycle + anti-duplicate
│   │   └── Transaction.js          ← API call logging
│   ├── services/
│   │   ├── topupProvider.js        ← External API + retry logic
│   │   └── orderService.js         ← Business logic (confirm, process, retry)
│   ├── bot/
│   │   ├── helpers.js              ← Message templates + keyboards
│   │   ├── middleware/
│   │   │   ├── session.js          ← In-memory session (swap Redis for scale)
│   │   │   └── userGuard.js        ← Auto-register + ban check
│   │   └── handlers/
│   │       ├── orderFlow.js        ← Full conversational flow
│   │       └── adminHandlers.js    ← Admin commands
│   ├── api/
│   │   ├── app.js                  ← Express app
│   │   ├── controllers/
│   │   │   └── orderController.js  ← REST API handlers
│   │   └── routes/
│   │       └── index.js            ← Route definitions + rate limiting
│   └── utils/
│       ├── logger.js               ← Winston multi-transport logger
│       └── retryJob.js             ← Cron: retry failed orders
├── scripts/
│   ├── schema.sql                  ← Full DB schema + seed data
│   └── migrate.js                  ← Run migration
├── logs/                           ← Auto-created by logger
├── uploads/                        ← Payment screenshots
├── ecosystem.config.js             ← PM2 config
├── .env.example                    ← Environment template
└── package.json
```

---

## 🤖 Bot Flow

```
/start
  └── Game Selection (Free Fire, PUBG, ML, etc.)
        └── Enter UID (validated by regex)
              └── Package Selection (price list)
                    └── Order Summary + Confirm/Cancel
                          └── Payment Instructions (bank transfer)
                                └── Upload Screenshot
                                      └── Admin notified (with Confirm/Reject buttons)
                                            └── Admin confirms → Auto Top-Up API called
                                                  ├── ✅ Success → User notified
                                                  └── ❌ Failed → Retry 3x → User notified
```

---

## 🚀 Deployment Guide (Ubuntu VPS + PM2)

### Step 1: Server Setup

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 20 LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install MySQL
sudo apt install -y mysql-server
sudo mysql_secure_installation

# Install PM2 globally
sudo npm install -g pm2

# Install Nginx (for reverse proxy)
sudo apt install -y nginx
```

### Step 2: MySQL Setup

```bash
sudo mysql -u root -p

CREATE USER 'topup_user'@'localhost' IDENTIFIED BY 'YourStrongPassword!';
CREATE DATABASE topup_bot_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
GRANT ALL PRIVILEGES ON topup_bot_db.* TO 'topup_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### Step 3: Application Setup

```bash
# Clone or upload your project
cd /var/www
git clone <your-repo> telegram-topup-bot
cd telegram-topup-bot

# Install dependencies
npm install --production

# Configure environment
cp .env.example .env
nano .env
# Fill in all values (BOT_TOKEN, DB credentials, ADMIN_CHAT_IDS, etc.)

# Run database migration (creates tables + seed data)
npm run migrate
```

### Step 4: Create a Telegram Bot

1. Open Telegram → search `@BotFather`
2. Send `/newbot`
3. Follow prompts → copy the **bot token**
4. Send `/setcommands` → set these commands:
   ```
   start - Start the bot
   menu - Show game menu
   orders - View order history
   cancel - Cancel current session
   ```
5. Paste token into `.env` as `BOT_TOKEN`

### Step 5: Get Admin Chat IDs

```bash
# Start bot, then send any message to it
# Visit: https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates
# Find "from": {"id": 123456789} — that's your chat ID
# Add to .env: ADMIN_CHAT_IDS=123456789
```

### Step 6: Start with PM2

```bash
# Production start
pm2 start ecosystem.config.js --env production

# Save PM2 process list (auto-start on reboot)
pm2 save
pm2 startup

# Check status
pm2 status
pm2 logs topup-bot
```

### Step 7: Nginx Reverse Proxy (for webhook)

```nginx
# /etc/nginx/sites-available/topupbot
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_cache_bypass $http_upgrade;
    }

    client_max_body_size 20M;
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/topupbot /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# Install SSL with Certbot
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

### Step 8: Switch to Webhook Mode

```bash
# In .env:
NODE_ENV=production
BOT_WEBHOOK_URL=https://yourdomain.com

# Restart
pm2 restart topup-bot
```

---

## 🔌 API Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/health` | None | Health check |
| GET | `/api/games` | None | List all games |
| GET | `/api/games/:slug/packages` | None | List packages for game |
| POST | `/api/topup` | Admin Key | Direct top-up (test/reseller) |
| POST | `/api/orders` | Admin Key | Create order via API |
| GET | `/api/orders/:id` | Admin Key | Get order details |
| POST | `/api/orders/:id/confirm` | Admin Key | Confirm payment |
| POST | `/api/webhook/payment` | Webhook Secret | Payment gateway callback |

**Admin Key header:** `X-Admin-Key: your_admin_api_key`  
**Webhook Secret header:** `X-Webhook-Secret: your_webhook_secret`

---

## 🔧 Swap Top-Up Provider

Edit `src/services/topupProvider.js`:

```javascript
// Change this URL and payload structure to match your provider
const response = await axios.post(
  `${process.env.TOPUP_API_URL}/topup`,
  {
    game: order.game_slug,
    uid: order.game_uid,
    package_id: order.pkg_id,
    // Add provider-specific fields here
  },
  { headers: { 'X-API-Key': process.env.TOPUP_API_KEY } }
);
```

---

## 📊 Order Status Flow

```
pending → paid → processing → success
                           → failed (retry up to 3x)
pending → cancelled (admin reject)
success → refunded (manual admin action)
```

---

## 🛡️ Security Features

- Rate limiting on all API endpoints
- Helmet.js security headers
- Admin-only commands via chat ID allowlist
- Webhook signature verification
- Anti-duplicate order check (5-minute window)
- Input validation with regex on UIDs

---

## 📝 Admin Commands

| Command | Description |
|---------|-------------|
| `/confirm ORD-XXXXXXXX-XXXX` | Confirm payment and process order |
| `/reject ORD-XXXXXXXX-XXXX [reason]` | Reject order |
| `/status ORD-XXXXXXXX-XXXX` | Check order details |

---

## 🔄 Scaling Notes

- **Sessions:** Replace in-memory sessions in `session.js` with Redis (`telegraf/session` + `@telegraf/session-redis`)
- **Queue:** Add Bull/BullMQ for processing orders in a queue instead of inline
- **Multi-instance:** Bot must run as single instance; API Express can be clustered separately
- **Database:** Add read replicas and connection pooling (PgBouncer/ProxySQL) for high load
