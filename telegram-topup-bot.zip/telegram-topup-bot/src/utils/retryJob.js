// src/utils/retryJob.js
/**
 * Cron job to retry failed top-up orders
 * Runs every 10 minutes
 */

const cron = require('node-cron');
const { retryFailedOrders } = require('../services/orderService');
const logger = require('./logger');

const startRetryJob = () => {
  // Run every 10 minutes
  cron.schedule('*/10 * * * *', async () => {
    logger.info('🔄 Running retry job for failed orders...');
    try {
      const results = await retryFailedOrders();
      if (results.length > 0) {
        const succeeded = results.filter(r => r.success).length;
        logger.info(`Retry job complete: ${succeeded}/${results.length} orders recovered`);
      }
    } catch (err) {
      logger.error('Retry job crashed:', err.message);
    }
  });

  logger.info('✅ Retry cron job started (every 10 minutes)');
};

module.exports = { startRetryJob };
