// src/bot/middleware/userGuard.js
/**
 * User Guard Middleware
 * - Registers new users automatically
 * - Blocks banned users
 * - Attaches dbUser to context
 */

const User = require('../../models/User');
const logger = require('../../utils/logger');

const userGuard = () => {
  return async (ctx, next) => {
    if (!ctx.from) return next();

    try {
      // Upsert user in database
      const dbUser = await User.upsert({
        telegram_id: ctx.from.id,
        username: ctx.from.username,
        first_name: ctx.from.first_name,
        last_name: ctx.from.last_name,
      });

      // Block banned users
      if (dbUser?.is_banned) {
        return ctx.reply('❌ Your account has been suspended. Contact support.');
      }

      // Attach to context for use in handlers
      ctx.dbUser = dbUser;
      ctx.isAdmin = User.isAdmin(ctx.from.id);

    } catch (error) {
      logger.error('UserGuard error:', error.message);
      // Don't block user if DB fails, just continue
    }

    return next();
  };
};

module.exports = { userGuard };
