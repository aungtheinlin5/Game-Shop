// src/bot/middleware/session.js
/**
 * In-memory session middleware for Telegraf
 * For production with many users, replace with Redis session store
 */

const sessions = new Map();

/**
 * Session cleanup: remove sessions older than 2 hours
 */
setInterval(() => {
  const TWO_HOURS = 2 * 60 * 60 * 1000;
  const now = Date.now();
  for (const [key, session] of sessions.entries()) {
    if (now - (session.__lastAccess || 0) > TWO_HOURS) {
      sessions.delete(key);
    }
  }
}, 30 * 60 * 1000); // Run every 30 minutes

/**
 * Session middleware factory
 */
const sessionMiddleware = () => {
  return async (ctx, next) => {
    const key = ctx.from?.id ? `user:${ctx.from.id}` : null;
    if (!key) return next();

    if (!sessions.has(key)) {
      sessions.set(key, { __lastAccess: Date.now() });
    }

    ctx.session = sessions.get(key);
    ctx.session.__lastAccess = Date.now();

    await next();

    // Persist updated session
    sessions.set(key, ctx.session);
  };
};

/**
 * Clear a user's session
 */
const clearSession = (userId) => {
  sessions.delete(`user:${userId}`);
};

module.exports = { sessionMiddleware, clearSession };
