// src/bot/handlers/adminHandlers.js
/**
 * Admin Command Handlers
 * Commands only accessible to configured admin users
 */

const Order = require('../../models/Order');
const { confirmPayment } = require('../../services/orderService');
const logger = require('../../utils/logger');

const registerAdminHandlers = (bot) => {

  // Guard: middleware for admin-only commands
  const adminOnly = async (ctx, next) => {
    if (!ctx.isAdmin) {
      return ctx.reply('❌ Admin only command.');
    }
    return next();
  };

  // ─── /confirm <order_number> ───────────────────────────────────────────────
  bot.command('confirm', adminOnly, async (ctx) => {
    const args = ctx.message.text.split(' ');
    const orderNumber = args[1]?.toUpperCase();

    if (!orderNumber) {
      return ctx.reply('Usage: /confirm <ORDER_NUMBER>\nExample: /confirm ORD-20241201-1234');
    }

    const order = await Order.findByOrderNumber(orderNumber);
    if (!order) return ctx.reply(`❌ Order ${orderNumber} not found.`);
    if (order.status !== 'pending') {
      return ctx.reply(`⚠️ Order ${orderNumber} is already ${order.status}.`);
    }

    await ctx.reply(`⚙️ Processing ${orderNumber}...`);

    try {
      const result = await confirmPayment(order.id, String(ctx.from.id));
      if (result.success) {
        await ctx.reply(`✅ ${orderNumber} completed!\nTX: ${result.transactionId}`);
        await bot.telegram.sendMessage(
          order.telegram_id,
          `🎉 *Top-Up Successful!*\n\nOrder: \`${order.order_number}\`\n💎 ${order.package_name}\nTX ID: \`${result.transactionId}\``,
          { parse_mode: 'Markdown' }
        );
      } else {
        await ctx.reply(`❌ ${orderNumber} failed: ${result.error}`);
      }
    } catch (err) {
      logger.error('Admin /confirm error:', err);
      await ctx.reply(`❌ Error: ${err.message}`);
    }
  });

  // ─── /reject <order_number> [reason] ──────────────────────────────────────
  bot.command('reject', adminOnly, async (ctx) => {
    const args = ctx.message.text.split(' ');
    const orderNumber = args[1]?.toUpperCase();
    const reason = args.slice(2).join(' ') || 'Rejected by admin';

    if (!orderNumber) return ctx.reply('Usage: /reject <ORDER_NUMBER> [reason]');

    const order = await Order.findByOrderNumber(orderNumber);
    if (!order) return ctx.reply(`❌ Order ${orderNumber} not found.`);

    await Order.updateStatus(order.id, 'cancelled', { notes: reason }, String(ctx.from.id));

    await ctx.reply(`✅ Order ${orderNumber} rejected.`);
    await bot.telegram.sendMessage(
      order.telegram_id,
      `❌ *Order Rejected*\n\nOrder: \`${orderNumber}\`\nReason: ${reason}\n\nAdmin ကို ဆက်သွယ်ပါ။`,
      { parse_mode: 'Markdown' }
    );
  });

  // ─── /status <order_number> ────────────────────────────────────────────────
  bot.command('status', adminOnly, async (ctx) => {
    const args = ctx.message.text.split(' ');
    const orderNumber = args[1]?.toUpperCase();

    if (!orderNumber) return ctx.reply('Usage: /status <ORDER_NUMBER>');

    const order = await Order.findByOrderNumber(orderNumber);
    if (!order) return ctx.reply(`❌ Order ${orderNumber} not found.`);

    const statusEmoji = {
      pending: '⏳', paid: '💰', processing: '⚙️',
      success: '✅', failed: '❌', cancelled: '🚫',
    }[order.status] || '❓';

    await ctx.reply(
      `📋 *Order Details*\n\n` +
      `Order: \`${order.order_number}\`\n` +
      `Status: ${statusEmoji} ${order.status}\n` +
      `Game: ${order.game_name}\n` +
      `UID: \`${order.game_uid}\`\n` +
      `Package: ${order.package_name}\n` +
      `Amount: ${order.amount} MMK\n` +
      `User TG ID: ${order.telegram_id}\n` +
      `Retry count: ${order.retry_count}\n` +
      `Created: ${order.created_at}`,
      { parse_mode: 'Markdown' }
    );
  });

  // ─── /broadcast <message> ──────────────────────────────────────────────────
  bot.command('broadcast', adminOnly, async (ctx) => {
    const message = ctx.message.text.replace('/broadcast ', '').trim();
    if (!message) return ctx.reply('Usage: /broadcast <message>');

    await ctx.reply(`📢 Broadcast feature requires iterating over all users. Implement with DB query.`);
    // TODO: Query all users and send message in batches
  });

};

module.exports = { registerAdminHandlers };
