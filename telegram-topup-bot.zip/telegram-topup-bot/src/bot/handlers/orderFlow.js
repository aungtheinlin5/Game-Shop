// src/bot/handlers/orderFlow.js
/**
 * Main Order Flow Handler
 * Manages the complete conversational flow:
 * /start → game → uid → package → confirm → payment → success/fail
 */

const path = require('path');
const fs = require('fs');
const Game = require('../../models/Game');
const Package = require('../../models/Package');
const Order = require('../../models/Order');
const User = require('../../models/User');
const { orderService } = require('../../services/orderService');
const {
  welcomeMessage,
  buildGameKeyboard,
  buildPackageKeyboard,
  orderSummaryMessage,
  confirmCancelKeyboard,
  paymentInstructionsMessage,
  adminPaymentNotification,
  adminActionKeyboard,
} = require('../helpers');
const logger = require('../../utils/logger');

// Upload directory for payment screenshots
const UPLOAD_DIR = path.join(__dirname, '../../../uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

/**
 * Register all order flow handlers on the bot instance
 */
const registerOrderFlow = (bot) => {

  // ─── /start ────────────────────────────────────────────────────────────────
  bot.start(async (ctx) => {
    ctx.session = {}; // Clear session on /start
    const games = await Game.findAllActive();

    await ctx.reply(
      welcomeMessage(ctx.from.first_name),
      { parse_mode: 'Markdown', ...buildGameKeyboard(games) }
    );
  });

  // ─── /menu ─────────────────────────────────────────────────────────────────
  bot.command('menu', async (ctx) => {
    ctx.session = {};
    const games = await Game.findAllActive();
    await ctx.reply('🎮 ဂိမ်းတစ်ခု ရွေးချယ်ပါ:', {
      parse_mode: 'Markdown',
      ...buildGameKeyboard(games),
    });
  });

  // ─── /orders - View order history ─────────────────────────────────────────
  bot.command('orders', async (ctx) => {
    if (!ctx.dbUser) return ctx.reply('Please start with /start');

    const orders = await Order.findByUserId(ctx.dbUser.id, 5);
    if (orders.length === 0) {
      return ctx.reply('📭 မှာယူမှု မရှိသေးပါ။');
    }

    const lines = orders.map((o) => {
      const emoji = {
        pending: '⏳', paid: '💰', processing: '⚙️',
        success: '✅', failed: '❌', cancelled: '🚫',
      }[o.status] || '❓';
      return `${emoji} \`${o.order_number}\` - ${o.game_name} ${o.package_name}`;
    });

    await ctx.reply(
      `📋 *မှာယူမှု မှတ်တမ်း (နောက်ဆုံး 5)*\n\n${lines.join('\n')}`,
      { parse_mode: 'Markdown' }
    );
  });

  // ─── /cancel - Cancel pending order ───────────────────────────────────────
  bot.command('cancel', async (ctx) => {
    ctx.session = {};
    await ctx.reply('✅ လက်ရှိ session ကို ဖျက်သိမ်းလိုက်ပါပြီ။ /start နှင့် အစပြုပါ။');
  });

  // ─── GAME SELECTION ────────────────────────────────────────────────────────
  bot.action(/^game:(.+)$/, async (ctx) => {
    const slug = ctx.match[1];
    const game = await Game.findBySlug(slug);
    if (!game) return ctx.answerCbQuery('Game not found');

    ctx.session.gameId = game.id;
    ctx.session.gameSlug = game.slug;
    ctx.session.gameName = game.name;
    ctx.session.step = 'awaiting_uid';

    await ctx.answerCbQuery();
    await ctx.editMessageText(
      `${game.icon} *${game.name}*\n\n` +
      `🆔 *${game.uid_label}* ထည့်သွင်းပါ:\n\n` +
      `📌 Example: \`${game.uid_example || 'Your UID'}\`\n\n` +
      `⚠️ UID မှန်ကန်ကြောင်း သေချာ စစ်ဆေးပါ!`,
      { parse_mode: 'Markdown' }
    );
  });

  // ─── Back to game list ─────────────────────────────────────────────────────
  bot.action('back:games', async (ctx) => {
    ctx.session = {};
    const games = await Game.findAllActive();
    await ctx.answerCbQuery();
    await ctx.editMessageText(
      '🎮 ဂိမ်းတစ်ခု ရွေးချယ်ပါ:',
      { parse_mode: 'Markdown', ...buildGameKeyboard(games) }
    );
  });

  // ─── PACKAGE SELECTION ─────────────────────────────────────────────────────
  bot.action(/^pkg:(\d+)$/, async (ctx) => {
    const pkgId = parseInt(ctx.match[1]);
    const pkg = await Package.findById(pkgId);
    if (!pkg) return ctx.answerCbQuery('Package not found');

    const game = await Game.findById(ctx.session.gameId);
    if (!game) return ctx.answerCbQuery('Session expired. Please /start again.');

    ctx.session.packageId = pkg.id;
    ctx.session.packageName = pkg.name;
    ctx.session.amount = pkg.price;
    ctx.session.step = 'awaiting_confirm';

    await ctx.answerCbQuery();
    await ctx.editMessageText(
      orderSummaryMessage(
        { gameUid: ctx.session.gameUid },
        game,
        pkg
      ),
      { parse_mode: 'Markdown', ...confirmCancelKeyboard() }
    );
  });

  // ─── ORDER CONFIRM ─────────────────────────────────────────────────────────
  bot.action('confirm:order', async (ctx) => {
    const { gameId, packageId, gameUid, amount } = ctx.session;
    if (!gameId || !packageId || !gameUid) {
      await ctx.answerCbQuery('Session expired');
      return ctx.reply('⚠️ Session expire ဖြစ်သွားပါပြီ။ /start နှင့် အစပြုပါ။');
    }

    await ctx.answerCbQuery('⏳ Order creating...');

    try {
      const { id: orderId, orderNumber } = await Order.create({
        userId: ctx.dbUser.id,
        gameId,
        packageId,
        gameUid,
        amount,
      });

      ctx.session.orderId = orderId;
      ctx.session.orderNumber = orderNumber;
      ctx.session.step = 'awaiting_payment';

      await ctx.editMessageText(
        paymentInstructionsMessage(orderNumber, amount),
        { parse_mode: 'Markdown' }
      );

      await ctx.reply('📸 ငွေလွှဲပြီးနောက် Screenshot ကို ဤ chat တွင် တိုက်ရိုက် ပို့ပေးပါ။');

    } catch (error) {
      if (error.message === 'DUPLICATE_ORDER') {
        await ctx.reply('⚠️ ဤ package ကို မကြာမီ မှာယူပြီးဖြစ်သည်။ ခဏစောင့်ပါ သို့မဟုတ် Admin ကို ဆက်သွယ်ပါ။');
      } else {
        logger.error('Order creation error:', error);
        await ctx.reply('❌ Order ဖန်တီးရာတွင် အမှားဖြစ်ပွားသည်။ ထပ်မံကြိုးစားပါ။');
      }
    }
  });

  // ─── ORDER CANCEL ──────────────────────────────────────────────────────────
  bot.action('cancel:order', async (ctx) => {
    ctx.session = {};
    await ctx.answerCbQuery('Cancelled');
    const games = await Game.findAllActive();
    await ctx.editMessageText('❌ Order ပယ်ဖျက်လိုက်ပါပြီ။ ဂိမ်းတစ်ခု ရွေးချယ်ပါ:', {
      ...buildGameKeyboard(games),
    });
  });

  // ─── ADMIN: Confirm payment via inline button ──────────────────────────────
  bot.action(/^admin:confirm:(.+)$/, async (ctx) => {
    if (!ctx.isAdmin) return ctx.answerCbQuery('❌ Admin only');

    const orderNumber = ctx.match[1];
    await ctx.answerCbQuery('⏳ Processing...');

    try {
      const { confirmPayment } = require('../../services/orderService');
      const order = await Order.findByOrderNumber(orderNumber);
      if (!order) return ctx.editMessageText(`❌ Order ${orderNumber} not found`);

      await ctx.editMessageText(`⚙️ Processing order ${orderNumber}...`);
      const result = await confirmPayment(order.id, String(ctx.from.id));

      if (result.success) {
        await ctx.editMessageText(`✅ Order ${orderNumber} completed! TX: ${result.transactionId}`);
        // Notify user
        await bot.telegram.sendMessage(
          order.telegram_id,
          `🎉 *Top-Up Successful!*\n\n📦 Order: \`${order.order_number}\`\n💎 ${order.package_name}\n🔖 TX: \`${result.transactionId}\`\n\nငွေဝင်ကြောင်း ဂိမ်းတွင် စစ်ဆေးပါ! 🎮`,
          { parse_mode: 'Markdown' }
        );
      } else {
        await ctx.editMessageText(`❌ Order ${orderNumber} failed: ${result.error}`);
        await bot.telegram.sendMessage(
          order.telegram_id,
          `❌ *Top-Up Failed*\n\nOrder: \`${order.order_number}\`\nAdmin မှ မကြာမီ ဆက်သွယ်ပါမည်။`,
          { parse_mode: 'Markdown' }
        );
      }
    } catch (err) {
      logger.error('Admin confirm error:', err);
      await ctx.editMessageText(`❌ Error: ${err.message}`);
    }
  });

  // ─── ADMIN: Reject payment ─────────────────────────────────────────────────
  bot.action(/^admin:reject:(.+)$/, async (ctx) => {
    if (!ctx.isAdmin) return ctx.answerCbQuery('❌ Admin only');

    const orderNumber = ctx.match[1];
    const order = await Order.findByOrderNumber(orderNumber);

    if (order) {
      await Order.updateStatus(order.id, 'cancelled', { notes: 'Rejected by admin' }, String(ctx.from.id));
      await bot.telegram.sendMessage(
        order.telegram_id,
        `❌ *Payment Rejected*\n\nOrder: \`${order.order_number}\`\n\nAdminမှ ငွေပေးချေမှုကို လက်မခံပါ။ Admin ကို ဆက်သွယ်ပါ။`,
        { parse_mode: 'Markdown' }
      );
    }

    await ctx.answerCbQuery('Rejected');
    await ctx.editMessageText(`❌ Order ${orderNumber} rejected.`);
  });

  // ─── TEXT MESSAGES (UID input) ─────────────────────────────────────────────
  bot.on('text', async (ctx) => {
    if (ctx.session?.step !== 'awaiting_uid') return;

    const uid = ctx.message.text.trim();
    const game = await Game.findById(ctx.session.gameId);
    if (!game) return ctx.reply('⚠️ Session expire ဖြစ်သွားပါပြီ။ /start နှင့် အစပြုပါ။');

    // Validate UID format if regex provided
    if (game.uid_regex) {
      const regex = new RegExp(game.uid_regex);
      if (!regex.test(uid)) {
        return ctx.reply(
          `❌ UID မမှန်ကန်ပါ!\n\n` +
          `📌 Example: \`${game.uid_example}\`\n\n` +
          `UID ကို ပြန်လည် ထည့်သွင်းပါ:`,
          { parse_mode: 'Markdown' }
        );
      }
    }

    ctx.session.gameUid = uid;
    ctx.session.step = 'awaiting_package';

    const packages = await Package.findByGameId(ctx.session.gameId);
    if (packages.length === 0) {
      return ctx.reply('⚠️ ဤဂိမ်းအတွက် package မရှိသေးပါ။ Admin ကို ဆက်သွယ်ပါ။');
    }

    await ctx.reply(
      `✅ UID: \`${uid}\`\n\n💎 Package ရွေးချယ်ပါ:`,
      { parse_mode: 'Markdown', ...buildPackageKeyboard(packages) }
    );
  });

  // ─── PHOTO MESSAGES (Payment Screenshot) ──────────────────────────────────
  bot.on('photo', async (ctx) => {
    if (ctx.session?.step !== 'awaiting_payment') {
      return ctx.reply('ℹ️ Order မှာယူပြီးမှ Screenshot ပို့ပေးပါ။ /start နှင့် အစပြုပါ။');
    }

    const { orderId, orderNumber } = ctx.session;
    if (!orderId) return ctx.reply('⚠️ Session expire ဖြစ်သွားပါပြီ။ /start နှင့် အစပြုပါ။');

    try {
      // Get highest resolution photo
      const photos = ctx.message.photo;
      const bestPhoto = photos[photos.length - 1];
      const fileId = bestPhoto.file_id;

      // Download and save screenshot
      const fileUrl = await ctx.telegram.getFileLink(fileId);
      const fileName = `${orderNumber}_${Date.now()}.jpg`;
      const filePath = path.join(UPLOAD_DIR, fileName);

      const axios = require('axios');
      const response = await axios.get(fileUrl.href, { responseType: 'arraybuffer' });
      fs.writeFileSync(filePath, response.data);

      const proofUrl = `/uploads/${fileName}`;

      // Update order with proof
      const order = await Order.findById(orderId);
      await Order.updateStatus(orderId, 'pending', { paymentProofUrl: proofUrl }, String(ctx.from.id));

      // Notify admins
      const adminIds = (process.env.ADMIN_CHAT_IDS || '').split(',').map(id => id.trim()).filter(Boolean);
      for (const adminId of adminIds) {
        try {
          await bot.telegram.sendPhoto(adminId, fileId, {
            caption: adminPaymentNotification(order, ctx.from),
            parse_mode: 'Markdown',
            ...adminActionKeyboard(orderNumber),
          });
        } catch (e) {
          logger.warn(`Could not notify admin ${adminId}:`, e.message);
        }
      }

      ctx.session.step = 'done';

      await ctx.reply(
        `✅ *Screenshot လက်ခံပြီးပါပြီ!*\n\n` +
        `📦 Order: \`${orderNumber}\`\n\n` +
        `⏳ Admin မှ စစ်ဆေးပြီးနောက် Auto Process ပြုလုပ်ပါမည်။\n` +
        `Processing time: 1-10 minutes\n\n` +
        `🔔 ပြီးဆုံးပါက Notification လာပါမည်။`,
        { parse_mode: 'Markdown' }
      );

    } catch (error) {
      logger.error('Photo upload error:', error);
      await ctx.reply('❌ Screenshot လက်ခံရာတွင် အမှားဖြစ်ပွားသည်။ ထပ်မံ ပို့ပေးပါ။');
    }
  });
};

module.exports = { registerOrderFlow };
