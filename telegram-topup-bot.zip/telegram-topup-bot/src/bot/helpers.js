// src/bot/helpers.js
/**
 * Message templates and keyboard builders for the Telegram bot
 */

const { Markup } = require('telegraf');

/**
 * Format price in MMK with commas
 */
const formatPrice = (amount) =>
  `${Number(amount).toLocaleString('en-US')} MMK`;

/**
 * Welcome message
 */
const welcomeMessage = (firstName) =>
  `🎮 *မင်္ဂလာပါ, ${firstName || 'သူငယ်ချင်း'}!*\n\n` +
  `🏆 *Game Top-Up Bot* မှ ကြိုဆိုပါသည်!\n\n` +
  `⚡ Fast & Secure Top-Up Service\n` +
  `✅ Auto Processing after Payment\n` +
  `🛡️ 100% Safe & Reliable\n\n` +
  `👇 ဂိမ်းတစ်ခု ရွေးချယ်ပါ:`;

/**
 * Build game selection keyboard from DB games
 */
const buildGameKeyboard = (games) => {
  const buttons = games.map((game) =>
    Markup.button.callback(`${game.icon} ${game.name}`, `game:${game.slug}`)
  );

  // Arrange in rows of 2
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }

  return Markup.inlineKeyboard(rows);
};

/**
 * Build package selection keyboard
 */
const buildPackageKeyboard = (packages) => {
  const buttons = packages.map((pkg) => {
    const bonus = pkg.bonus ? ` (${pkg.bonus})` : '';
    const label = `💎 ${pkg.diamonds} Diamonds${bonus} - ${formatPrice(pkg.price)}`;
    return Markup.button.callback(label, `pkg:${pkg.id}`);
  });

  const rows = buttons.map((btn) => [btn]); // One package per row for clarity
  rows.push([Markup.button.callback('🔙 ဂိမ်း ပြောင်းရန်', 'back:games')]);

  return Markup.inlineKeyboard(rows);
};

/**
 * Format order summary message
 */
const orderSummaryMessage = (order, game, pkg) =>
  `📋 *Order Summary*\n\n` +
  `🎮 Game: *${game.name}*\n` +
  `🆔 UID: \`${order.gameUid}\`\n` +
  `💎 Package: *${pkg.name}*\n` +
  `💰 Amount: *${formatPrice(pkg.price)}*\n\n` +
  `⚠️ UID မှန်ကန်ကြောင်း သေချာ စစ်ဆေးပါ။\n` +
  `❌ မှားသော UID ဖြင့် ငွေပေးချေပါက တာဝန်မယူပါ။`;

/**
 * Confirm/Cancel keyboard
 */
const confirmCancelKeyboard = () =>
  Markup.inlineKeyboard([
    [
      Markup.button.callback('✅ အတည်ပြုမည်', 'confirm:order'),
      Markup.button.callback('❌ ပယ်ဖျက်မည်', 'cancel:order'),
    ],
  ]);

/**
 * Payment instructions message
 */
const paymentInstructionsMessage = (orderNumber, amount) =>
  `💳 *Payment Instructions*\n\n` +
  `📦 Order: \`${orderNumber}\`\n` +
  `💰 Amount: *${formatPrice(amount)}*\n\n` +
  `━━━━━━━━━━━━━━━━━━━━\n` +
  `🏦 *${process.env.PAYMENT_BANK_NAME || 'KBZ Pay'}*\n` +
  `📱 Account: \`${process.env.PAYMENT_ACCOUNT_NUMBER || '09xxxxxxxxx'}\`\n` +
  `👤 Name: *${process.env.PAYMENT_ACCOUNT_NAME || 'Top-Up Bot'}*\n` +
  `━━━━━━━━━━━━━━━━━━━━\n\n` +
  `📸 ငွေလွှဲပြီးနောက် *Screenshot* ပို့ပေးပါ\n` +
  `⏳ Processing time: 1-10 minutes\n\n` +
  `⚠️ Order Number ကို မှတ်ထားပါ: \`${orderNumber}\``;

/**
 * Success message
 */
const successMessage = (order, transactionId) =>
  `🎉 *Top-Up Successful!*\n\n` +
  `📦 Order: \`${order.order_number}\`\n` +
  `🎮 Game: *${order.game_name}*\n` +
  `🆔 UID: \`${order.game_uid}\`\n` +
  `💎 Package: *${order.package_name}*\n` +
  `🔖 TX ID: \`${transactionId}\`\n\n` +
  `✅ Top-Up ပြီးမြောက်ပါပြီ! ဂိမ်းတွင် စစ်ဆေးပါ။\n\n` +
  `🙏 ဝယ်ယူပေးသည့်အတွက် ကျေးဇူးတင်ပါသည်!`;

/**
 * Failure message
 */
const failureMessage = (order) =>
  `❌ *Top-Up Failed*\n\n` +
  `📦 Order: \`${order.order_number}\`\n\n` +
  `😢 Top-Up မအောင်မြင်ပါ။ Admin မှ ဆက်သွယ်ပေးပါမည်။\n` +
  `📞 Support: @YourAdminUsername`;

/**
 * Admin notification for new payment proof
 */
const adminPaymentNotification = (order, user) =>
  `🔔 *New Payment Received!*\n\n` +
  `📦 Order: \`${order.order_number}\`\n` +
  `👤 User: ${user.first_name || 'Unknown'} (ID: ${user.telegram_id})\n` +
  `🎮 Game: ${order.game_name}\n` +
  `🆔 UID: \`${order.game_uid}\`\n` +
  `💎 Package: ${order.package_name}\n` +
  `💰 Amount: ${formatPrice(order.amount)}\n\n` +
  `Use: /confirm ${order.order_number}`;

/**
 * Admin action keyboard
 */
const adminActionKeyboard = (orderNumber) =>
  Markup.inlineKeyboard([
    [
      Markup.button.callback('✅ Confirm Payment', `admin:confirm:${orderNumber}`),
      Markup.button.callback('❌ Reject', `admin:reject:${orderNumber}`),
    ],
  ]);

module.exports = {
  welcomeMessage,
  buildGameKeyboard,
  buildPackageKeyboard,
  orderSummaryMessage,
  confirmCancelKeyboard,
  paymentInstructionsMessage,
  successMessage,
  failureMessage,
  adminPaymentNotification,
  adminActionKeyboard,
  formatPrice,
};
