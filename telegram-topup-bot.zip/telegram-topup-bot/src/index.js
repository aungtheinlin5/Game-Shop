// src/index.js
/**
 * Telegram Top-Up Bot - Main Entry Point
 * Initializes database, bot, API server, and cron jobs
 */

require('dotenv').config();
const { Telegraf } = require('telegraf');
const { createApp } = require('./api/app');
const { initDatabase } = require('./config/database');
const { sessionMiddleware } = require('./bot/middleware/session');
const { userGuard } = require('./bot/middleware/userGuard');
const { registerOrderFlow } = require('./bot/handlers/orderFlow');
const { registerAdminHandlers } = require('./bot/handlers/adminHandlers');
const { startRetryJob } = require('./utils/retryJob');
const logger = require('./utils/logger');

const BOT_TOKEN = process.env.BOT_TOKEN;
const PORT = parseInt(process.env.PORT) || 3000;
const NODE_ENV = process.env.NODE_ENV || 'development';
const WEBHOOK_URL = process.env.BOT_WEBHOOK_URL;

if (!BOT_TOKEN) {
  logger.error('❌ BOT_TOKEN is required in .env');
  process.exit(1);
}

const main = async () => {
  // ─── 1. Initialize Database ────────────────────────────────────────────────
  logger.info('Initializing database...');
  await initDatabase();

  // ─── 2. Create Telegraf Bot ────────────────────────────────────────────────
  const bot = new Telegraf(BOT_TOKEN);

  // Global error handler
  bot.catch((err, ctx) => {
    logger.error(`Bot error for ${ctx.updateType}:`, err.message);
    ctx.reply('❌ Something went wrong. Please try again or contact support.').catch(() => {});
  });

  // ─── 3. Register Middleware ────────────────────────────────────────────────
  bot.use(sessionMiddleware());
  bot.use(userGuard());

  // ─── 4. Register Handlers ──────────────────────────────────────────────────
  registerOrderFlow(bot);
  registerAdminHandlers(bot);

  // ─── 5. Start Express API ──────────────────────────────────────────────────
  const app = createApp();

  if (NODE_ENV === 'production' && WEBHOOK_URL) {
    // ── Webhook mode (production) ──────────────────────────────────────────
    const webhookPath = `/telegram-webhook/${BOT_TOKEN}`;

    app.use(webhookPath, bot.webhookCallback(webhookPath));

    await bot.telegram.setWebhook(`${WEBHOOK_URL}${webhookPath}`);
    logger.info(`✅ Webhook set to ${WEBHOOK_URL}${webhookPath}`);

    app.listen(PORT, () => {
      logger.info(`🚀 Server running on port ${PORT} (webhook mode)`);
    });
  } else {
    // ── Long polling mode (development) ───────────────────────────────────
    await bot.telegram.deleteWebhook();

    app.listen(PORT, () => {
      logger.info(`🚀 Server running on port ${PORT} (polling mode)`);
    });

    bot.launch();
    logger.info('✅ Bot started (long polling)');
  }

  // ─── 6. Start Retry Cron Job ───────────────────────────────────────────────
  startRetryJob();

  // ─── 7. Graceful Shutdown ──────────────────────────────────────────────────
  const shutdown = async (signal) => {
    logger.info(`${signal} received. Shutting down gracefully...`);
    bot.stop(signal);
    process.exit(0);
  };

  process.once('SIGINT', () => shutdown('SIGINT'));
  process.once('SIGTERM', () => shutdown('SIGTERM'));

  logger.info(`
  ┌─────────────────────────────────────┐
  │  🎮 GAME TOP-UP BOT STARTED         │
  │  Mode: ${NODE_ENV.padEnd(29)}│
  │  Port: ${String(PORT).padEnd(29)}│
  └─────────────────────────────────────┘
  `);
};

main().catch((err) => {
  logger.error('Fatal startup error:', err);
  process.exit(1);
});
