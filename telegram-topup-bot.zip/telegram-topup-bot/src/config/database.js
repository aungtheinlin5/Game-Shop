// src/config/database.js
const mysql = require('mysql2/promise');
const logger = require('../utils/logger');

let pool = null;

/**
 * Initialize MySQL connection pool
 */
const initDatabase = async () => {
  try {
    pool = mysql.createPool({
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT) || 3306,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      connectionLimit: parseInt(process.env.DB_CONNECTION_LIMIT) || 10,
      waitForConnections: true,
      queueLimit: 0,
      enableKeepAlive: true,
      keepAliveInitialDelay: 0,
      timezone: '+00:00',
    });

    // Test connection
    const conn = await pool.getConnection();
    await conn.ping();
    conn.release();

    logger.info('✅ Database connection pool initialized');
    return pool;
  } catch (error) {
    logger.error('❌ Database connection failed:', error.message);
    throw error;
  }
};

/**
 * Get database pool instance
 */
const getPool = () => {
  if (!pool) throw new Error('Database not initialized. Call initDatabase() first.');
  return pool;
};

/**
 * Execute a query with automatic connection management
 */
const query = async (sql, params = []) => {
  const connection = await getPool().getConnection();
  try {
    const [rows] = await connection.execute(sql, params);
    return rows;
  } finally {
    connection.release();
  }
};

/**
 * Execute queries within a transaction
 */
const transaction = async (callback) => {
  const connection = await getPool().getConnection();
  await connection.beginTransaction();
  try {
    const result = await callback(connection);
    await connection.commit();
    return result;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

module.exports = { initDatabase, getPool, query, transaction };
