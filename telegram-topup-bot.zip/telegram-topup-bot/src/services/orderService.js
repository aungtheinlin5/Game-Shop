// src/services/orderService.js
/**
 * Order Service
 * Core business logic for order lifecycle management
 */

const Order = require('../models/Order');
const User = require('../models/User');
const { executeTopUp } = require('./topupProvider');
const logger = require('../utils/logger');

/**
 * Process a confirmed (paid) order through the top-up API
 * This is called after admin/webhook confirms payment
 */
const processOrder = async (orderId, performedBy = 'system') => {
  const order = await Order.findById(orderId);

  if (!order) {
    throw new Error(`Order ${orderId} not found`);
  }

  if (order.status !== 'paid') {
    throw new Error(`Order ${orderId} is not in 'paid' status (current: ${order.status})`);
  }

  // Mark as processing
  await Order.updateStatus(orderId, 'processing', {}, performedBy);

  // Call provider API
  const result = await executeTopUp(order);

  if (result.success) {
    // Mark order as success
    await Order.updateStatus(
      orderId,
      'success',
      { notes: `Provider TX: ${result.transactionId}` },
      'system'
    );

    // Update user stats
    await User.incrementStats(order.user_id, order.amount);

    logger.info(`Order ${order.order_number} completed successfully`, {
      providerTx: result.transactionId,
    });

    return {
      success: true,
      order,
      transactionId: result.transactionId,
    };
  } else {
    // Mark as failed (but keep retryable flag)
    await Order.updateStatus(
      orderId,
      'failed',
      {
        notes: result.error,
        retryIncrement: true,
      },
      'system'
    );

    logger.error(`Order ${order.order_number} processing failed`, { error: result.error });

    return {
      success: false,
      order,
      error: result.error,
      retryable: result.retryable,
    };
  }
};

/**
 * Confirm payment for an order (admin action)
 */
const confirmPayment = async (orderId, confirmedBy = 'admin') => {
  const order = await Order.findById(orderId);

  if (!order) throw new Error('Order not found');
  if (order.status !== 'pending') throw new Error(`Order is not pending (status: ${order.status})`);

  await Order.updateStatus(orderId, 'paid', { confirmedBy }, confirmedBy);

  // Immediately process after confirmation
  return processOrder(orderId, confirmedBy);
};

/**
 * Webhook-based payment confirmation
 * Called from payment gateway callback
 */
const confirmPaymentWebhook = async ({ orderNumber, paymentRef, gateway }) => {
  const order = await Order.findByOrderNumber(orderNumber);

  if (!order) throw new Error(`Order ${orderNumber} not found`);
  if (order.status !== 'pending') {
    logger.warn(`Webhook received for non-pending order ${orderNumber}`);
    return { skipped: true, reason: 'Order not pending' };
  }

  logger.info(`Payment webhook received for ${orderNumber}`, { paymentRef, gateway });

  await Order.updateStatus(
    order.id,
    'paid',
    { confirmedBy: `webhook:${gateway}`, notes: `Payment ref: ${paymentRef}` },
    `webhook:${gateway}`
  );

  return processOrder(order.id, `webhook:${gateway}`);
};

/**
 * Retry failed orders (called by cron job)
 */
const retryFailedOrders = async () => {
  const maxRetries = parseInt(process.env.MAX_RETRY_ATTEMPTS) || 3;
  const pendingRetry = await Order.findPendingRetry(maxRetries);

  logger.info(`Retry job: found ${pendingRetry.length} orders to retry`);

  const results = [];
  for (const order of pendingRetry) {
    try {
      // Reset to 'paid' so processOrder can pick it up
      await Order.updateStatus(order.id, 'paid', {}, 'retry_job');
      const result = await processOrder(order.id, 'retry_job');
      results.push({ orderId: order.id, ...result });
    } catch (err) {
      logger.error(`Retry failed for order ${order.id}:`, err.message);
      results.push({ orderId: order.id, success: false, error: err.message });
    }
  }

  return results;
};

module.exports = { processOrder, confirmPayment, confirmPaymentWebhook, retryFailedOrders };
