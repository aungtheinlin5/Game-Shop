// src/services/topupProvider.js
/**
 * Top-Up Provider API Integration Service
 * Handles all communication with the external top-up provider.
 * Swap out the implementation here to change providers.
 */

const axios = require('axios');
const logger = require('../utils/logger');
const Transaction = require('../models/Transaction');

const MAX_RETRIES = parseInt(process.env.MAX_RETRY_ATTEMPTS) || 3;
const RETRY_DELAY_MS = parseInt(process.env.RETRY_DELAY_MS) || 5000;

/**
 * Delay helper for retry backoff
 */
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Build the provider-specific request payload
 * Modify this to match your provider's API contract
 */
const buildRequestPayload = (order) => ({
  game: order.game_slug,
  uid: order.game_uid,
  package_id: order.pkg_id,
  order_ref: order.order_number,
  // Add provider-specific fields below:
  // server: order.game_server,
  // api_key: process.env.TOPUP_API_KEY,
});

/**
 * Call top-up provider API (single attempt)
 */
const callProviderAPI = async (payload) => {
  const startTime = Date.now();

  const response = await axios.post(
    `${process.env.TOPUP_API_URL}/topup`,
    payload,
    {
      timeout: 30000, // 30 second timeout
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': process.env.TOPUP_API_KEY,
        'X-API-Secret': process.env.TOPUP_API_SECRET,
      },
    }
  );

  return {
    data: response.data,
    httpStatus: response.status,
    durationMs: Date.now() - startTime,
  };
};

/**
 * Main top-up execution function with retry logic
 * @param {Object} order - Full order object from DB
 * @returns {Object} { success: boolean, transactionId: string, error: string }
 */
const executeTopUp = async (order) => {
  const payload = buildRequestPayload(order);
  logger.info(`Executing top-up for order ${order.order_number}`, { payload });

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    // Log this attempt in the transactions table
    const txRecord = await Transaction.create({
      orderId: order.id,
      attemptNumber: attempt,
      requestPayload: payload,
    });

    try {
      const { data, httpStatus, durationMs } = await callProviderAPI(payload);

      // Provider returned success
      if (data.status === 'success') {
        await Transaction.updateResult(txRecord.id, {
          providerTransactionId: data.transaction_id,
          responsePayload: data,
          status: 'success',
          httpStatus,
          durationMs,
        });

        logger.info(`Top-up SUCCESS for order ${order.order_number}`, {
          providerTxId: data.transaction_id,
          attempt,
        });

        return {
          success: true,
          transactionId: data.transaction_id,
          providerData: data,
        };
      }

      // Provider returned failure (not a network error)
      const errorMsg = data.message || data.error || 'Provider returned failure';
      await Transaction.updateResult(txRecord.id, {
        responsePayload: data,
        status: 'failed',
        errorMessage: errorMsg,
        httpStatus,
        durationMs,
      });

      logger.warn(`Top-up attempt ${attempt} failed for order ${order.order_number}: ${errorMsg}`);

      // Don't retry on non-retryable errors (e.g. invalid UID)
      if (data.code === 'INVALID_UID' || data.code === 'INVALID_PACKAGE') {
        return { success: false, error: errorMsg, retryable: false };
      }

    } catch (error) {
      const isTimeout = error.code === 'ECONNABORTED';
      const isNetworkError = !error.response;
      const httpStatus = error.response?.status;
      const errorMsg = error.response?.data?.message || error.message;

      await Transaction.updateResult(txRecord.id, {
        responsePayload: error.response?.data || null,
        status: 'failed',
        errorMessage: errorMsg,
        httpStatus: httpStatus || null,
        durationMs: Date.now() - Date.now(),
      });

      logger.error(`Top-up attempt ${attempt} error for order ${order.order_number}`, {
        error: errorMsg,
        isTimeout,
        isNetworkError,
      });
    }

    // Wait before retry (exponential backoff)
    if (attempt < MAX_RETRIES) {
      const delay = RETRY_DELAY_MS * Math.pow(2, attempt - 1);
      logger.info(`Waiting ${delay}ms before retry ${attempt + 1}...`);
      await sleep(delay);
    }
  }

  // All attempts exhausted
  logger.error(`Top-up FAILED after ${MAX_RETRIES} attempts for order ${order.order_number}`);
  return {
    success: false,
    error: `Failed after ${MAX_RETRIES} attempts`,
    retryable: true,
  };
};

/**
 * Check top-up status from provider (for verification)
 */
const checkTopUpStatus = async (providerTransactionId) => {
  try {
    const response = await axios.get(
      `${process.env.TOPUP_API_URL}/status/${providerTransactionId}`,
      {
        headers: { 'X-API-Key': process.env.TOPUP_API_KEY },
        timeout: 15000,
      }
    );
    return response.data;
  } catch (error) {
    logger.error('Status check failed:', error.message);
    return null;
  }
};

module.exports = { executeTopUp, checkTopUpStatus };
