// src/api/controllers/orderController.js
/**
 * Order API Controller
 * REST endpoints for order management
 */

const Order = require('../../models/Order');
const { confirmPayment, confirmPaymentWebhook, processOrder } = require('../../services/orderService');
const logger = require('../../utils/logger');

/**
 * POST /api/orders
 * Create order (for direct API use / reseller integration)
 */
const createOrder = async (req, res) => {
  try {
    const { userId, gameId, packageId, gameUid, gameServer } = req.body;

    const Order_m = require('../../models/Order');
    const Package_m = require('../../models/Package');
    const pkg = await Package_m.findById(packageId);
    if (!pkg) return res.status(404).json({ error: 'Package not found' });

    const order = await Order_m.create({
      userId, gameId, packageId, gameUid, gameServer, amount: pkg.price,
    });

    res.status(201).json({ success: true, order });
  } catch (err) {
    if (err.message === 'DUPLICATE_ORDER') {
      return res.status(409).json({ error: 'Duplicate order detected' });
    }
    logger.error('createOrder error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
};

/**
 * GET /api/orders/:id
 */
const getOrder = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    res.json({ success: true, order });
  } catch (err) {
    logger.error('getOrder error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
};

/**
 * POST /api/orders/:id/confirm
 * Admin confirm payment
 */
const adminConfirmOrder = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });

    const result = await confirmPayment(order.id, 'api_admin');
    res.json({ success: result.success, transactionId: result.transactionId, error: result.error });
  } catch (err) {
    logger.error('adminConfirmOrder error:', err);
    res.status(500).json({ error: err.message });
  }
};

/**
 * POST /api/webhook/payment
 * Payment gateway webhook (auto-confirm)
 */
const paymentWebhook = async (req, res) => {
  try {
    // Verify webhook signature
    const secret = req.headers['x-webhook-secret'];
    if (secret !== process.env.WEBHOOK_SECRET) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const { order_number, payment_ref, gateway } = req.body;
    if (!order_number) return res.status(400).json({ error: 'Missing order_number' });

    // Respond immediately, process async
    res.json({ success: true, message: 'Webhook received' });

    // Process in background
    confirmPaymentWebhook({ orderNumber: order_number, paymentRef: payment_ref, gateway })
      .catch(err => logger.error('Webhook processing error:', err));

  } catch (err) {
    logger.error('paymentWebhook error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
};

/**
 * POST /api/topup (Mock-compatible endpoint)
 * Mirrors the provider API structure for testing
 */
const directTopup = async (req, res) => {
  try {
    const { game, uid, package_id } = req.body;
    if (!game || !uid || !package_id) {
      return res.status(400).json({ error: 'Missing required fields: game, uid, package_id' });
    }

    // Mock response for testing - replace with real provider call
    const txId = `TX${Date.now()}`;
    logger.info('Direct top-up request', { game, uid, package_id, txId });

    res.json({
      status: 'success',
      transaction_id: txId,
      game,
      uid,
      package_id,
      processed_at: new Date().toISOString(),
    });
  } catch (err) {
    logger.error('directTopup error:', err);
    res.status(500).json({ status: 'failed', error: 'Internal server error' });
  }
};

module.exports = { createOrder, getOrder, adminConfirmOrder, paymentWebhook, directTopup };
