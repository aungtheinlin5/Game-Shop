// src/api/routes/index.js
const express = require('express');
const router = express.Router();
const rateLimit = require('express-rate-limit');
const {
  createOrder,
  getOrder,
  adminConfirmOrder,
  paymentWebhook,
  directTopup,
} = require('../controllers/orderController');

// ─── Rate Limiters ─────────────────────────────────────────────────────────
const generalLimit = rateLimit({ windowMs: 60_000, max: 60 });
const webhookLimit = rateLimit({ windowMs: 60_000, max: 200 });

// ─── API Key auth for admin endpoints ─────────────────────────────────────
const adminAuth = (req, res, next) => {
  const key = req.headers['x-admin-key'];
  if (key !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
};

// ─── Health check ──────────────────────────────────────────────────────────
router.get('/health', (req, res) => res.json({ status: 'ok', timestamp: new Date().toISOString() }));

// ─── Orders ────────────────────────────────────────────────────────────────
router.post('/orders', generalLimit, adminAuth, createOrder);
router.get('/orders/:id', generalLimit, adminAuth, getOrder);
router.post('/orders/:id/confirm', generalLimit, adminAuth, adminConfirmOrder);

// ─── Payment webhook (no auth key, uses webhook secret in body) ────────────
router.post('/webhook/payment', webhookLimit, paymentWebhook);

// ─── Direct top-up endpoint (for testing / reseller) ──────────────────────
router.post('/topup', generalLimit, adminAuth, directTopup);

// ─── Games & Packages (public read) ───────────────────────────────────────
const Game = require('../../models/Game');
const Package = require('../../models/Package');

router.get('/games', generalLimit, async (req, res) => {
  const games = await Game.findAllActive();
  res.json({ success: true, games });
});

router.get('/games/:slug/packages', generalLimit, async (req, res) => {
  const game = await Game.findBySlug(req.params.slug);
  if (!game) return res.status(404).json({ error: 'Game not found' });
  const packages = await Package.findByGameId(game.id);
  res.json({ success: true, packages });
});

module.exports = router;
