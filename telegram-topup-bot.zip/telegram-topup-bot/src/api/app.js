// src/api/app.js
/**
 * Express Application
 */

const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const logger = require('../utils/logger');
const routes = require('./routes/index');

const createApp = () => {
  const app = express();

  // ─── Security headers ──────────────────────────────────────────────────────
  app.use(helmet());

  // ─── Body parsers ──────────────────────────────────────────────────────────
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // ─── HTTP access log ───────────────────────────────────────────────────────
  app.use(morgan('combined', {
    stream: { write: (msg) => logger.info(msg.trim()) },
  }));

  // ─── Static files (payment screenshots) ───────────────────────────────────
  app.use('/uploads', express.static(path.join(__dirname, '../../uploads')));

  // ─── API routes ───────────────────────────────────────────────────────────
  app.use('/api', routes);

  // ─── 404 handler ──────────────────────────────────────────────────────────
  app.use((req, res) => {
    res.status(404).json({ error: 'Route not found' });
  });

  // ─── Global error handler ──────────────────────────────────────────────────
  app.use((err, req, res, next) => {
    logger.error('Unhandled error:', err);
    res.status(500).json({ error: 'Internal server error' });
  });

  return app;
};

module.exports = { createApp };
