// src/models/Package.js
const { query } = require('../config/database');

class Package {
  /**
   * Get all active packages for a game
   */
  static async findByGameId(gameId) {
    return query(
      'SELECT * FROM packages WHERE game_id = ? AND is_active = 1 ORDER BY sort_order ASC',
      [gameId]
    );
  }

  /**
   * Find a specific package by ID
   */
  static async findById(id) {
    const rows = await query('SELECT * FROM packages WHERE id = ?', [id]);
    return rows[0] || null;
  }

  /**
   * Find package by game_id + package_id string
   */
  static async findByPackageId(gameId, packageId) {
    const rows = await query(
      'SELECT * FROM packages WHERE game_id = ? AND package_id = ? AND is_active = 1',
      [gameId, packageId]
    );
    return rows[0] || null;
  }
}

module.exports = Package;
