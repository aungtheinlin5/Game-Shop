// src/models/Transaction.js
const { query } = require('../config/database');

class Transaction {
  /**
   * Log an API transaction attempt
   */
  static async create({ orderId, attemptNumber, requestPayload }) {
    const [result] = await query(
      `INSERT INTO transactions (order_id, attempt_number, request_payload, status)
       VALUES (?, ?, ?, 'pending')`,
      [orderId, attemptNumber, JSON.stringify(requestPayload)]
    );
    // mysql2 execute returns array; use insertId
    const rows = await query('SELECT * FROM transactions WHERE id = LAST_INSERT_ID()');
    return rows[0];
  }

  /**
   * Update transaction with result
   */
  static async updateResult(transactionId, { providerTransactionId, responsePayload, status, errorMessage, httpStatus, durationMs }) {
    await query(
      `UPDATE transactions SET
         provider_transaction_id = ?,
         response_payload = ?,
         status = ?,
         error_message = ?,
         http_status = ?,
         duration_ms = ?
       WHERE id = ?`,
      [
        providerTransactionId || null,
        JSON.stringify(responsePayload),
        status,
        errorMessage || null,
        httpStatus || null,
        durationMs || null,
        transactionId,
      ]
    );
  }

  /**
   * Get all transactions for an order
   */
  static async findByOrderId(orderId) {
    return query(
      'SELECT * FROM transactions WHERE order_id = ? ORDER BY attempt_number ASC',
      [orderId]
    );
  }
}

module.exports = Transaction;
