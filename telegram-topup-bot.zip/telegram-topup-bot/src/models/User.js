// src/models/User.js
const { query, transaction } = require('../config/database');

class User {
  /**
   * Find user by Telegram ID
   */
  static async findByTelegramId(telegramId) {
    const rows = await query('SELECT * FROM users WHERE telegram_id = ?', [telegramId]);
    return rows[0] || null;
  }

  /**
   * Upsert user from Telegram context (create or update)
   */
  static async upsert({ telegram_id, username, first_name, last_name }) {
    await query(
      `INSERT INTO users (telegram_id, username, first_name, last_name, last_active)
       VALUES (?, ?, ?, ?, NOW())
       ON DUPLICATE KEY UPDATE
         username = VALUES(username),
         first_name = VALUES(first_name),
         last_name = VALUES(last_name),
         last_active = NOW()`,
      [telegram_id, username || null, first_name || null, last_name || null]
    );
    return User.findByTelegramId(telegram_id);
  }

  /**
   * Increment user order stats after successful order
   */
  static async incrementStats(userId, amount) {
    await query(
      'UPDATE users SET total_orders = total_orders + 1, total_spent = total_spent + ? WHERE id = ?',
      [amount, userId]
    );
  }

  /**
   * Check if user is banned
   */
  static async isBanned(telegramId) {
    const rows = await query(
      'SELECT is_banned FROM users WHERE telegram_id = ?',
      [telegramId]
    );
    return rows[0]?.is_banned === 1;
  }

  /**
   * Check if user is admin
   */
  static isAdmin(telegramId) {
    const adminIds = (process.env.ADMIN_CHAT_IDS || '').split(',').map(id => id.trim());
    return adminIds.includes(String(telegramId));
  }
}

module.exports = User;
