// src/models/Game.js
const { query } = require('../config/database');

class Game {
  /**
   * Get all active games sorted by order
   */
  static async findAllActive() {
    return query(
      'SELECT * FROM games WHERE is_active = 1 ORDER BY sort_order ASC'
    );
  }

  /**
   * Find game by slug (e.g. 'freefire')
   */
  static async findBySlug(slug) {
    const rows = await query('SELECT * FROM games WHERE slug = ? AND is_active = 1', [slug]);
    return rows[0] || null;
  }

  /**
   * Find game by ID
   */
  static async findById(id) {
    const rows = await query('SELECT * FROM games WHERE id = ?', [id]);
    return rows[0] || null;
  }
}

module.exports = Game;
