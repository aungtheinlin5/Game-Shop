// src/models/Order.js
const { query, transaction } = require('../config/database');
const logger = require('../utils/logger');

class Order {
  /**
   * Generate a human-readable order number
   */
  static generateOrderNumber() {
    const date = new Date();
    const dateStr = date.toISOString().slice(0, 10).replace(/-/g, '');
    const rand = Math.floor(Math.random() * 9000) + 1000;
    return `ORD-${dateStr}-${rand}`;
  }

  /**
   * Create a new order
   */
  static async create({ userId, gameId, packageId, gameUid, gameServer, amount }) {
    return transaction(async (conn) => {
      // Anti-duplicate: check for pending order with same uid+package in last 5 minutes
      const [existing] = await conn.execute(
        `SELECT id FROM orders
         WHERE user_id = ? AND game_id = ? AND package_id = ? AND game_uid = ?
         AND status IN ('pending', 'paid', 'processing')
         AND created_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)`,
        [userId, gameId, packageId, gameUid]
      );

      if (existing.length > 0) {
        throw new Error('DUPLICATE_ORDER');
      }

      const orderNumber = Order.generateOrderNumber();

      const [result] = await conn.execute(
        `INSERT INTO orders (order_number, user_id, game_id, package_id, game_uid, game_server, amount, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')`,
        [orderNumber, userId, gameId, packageId, gameUid, gameServer || null, amount]
      );

      // Audit log
      await conn.execute(
        `INSERT INTO audit_logs (entity_type, entity_id, action, new_value, performed_by)
         VALUES ('order', ?, 'created', ?, ?)`,
        [result.insertId, JSON.stringify({ orderNumber, status: 'pending' }), String(userId)]
      );

      return { id: result.insertId, orderNumber };
    });
  }

  /**
   * Find order by ID with full details
   */
  static async findById(id) {
    const rows = await query(
      `SELECT o.*, g.name as game_name, g.slug as game_slug,
              p.name as package_name, p.package_id as pkg_id,
              u.telegram_id, u.first_name
       FROM orders o
       JOIN games g ON o.game_id = g.id
       JOIN packages p ON o.package_id = p.id
       JOIN users u ON o.user_id = u.id
       WHERE o.id = ?`,
      [id]
    );
    return rows[0] || null;
  }

  /**
   * Find order by order number
   */
  static async findByOrderNumber(orderNumber) {
    const rows = await query(
      `SELECT o.*, g.name as game_name, g.slug as game_slug,
              p.name as package_name, p.package_id as pkg_id,
              u.telegram_id, u.first_name
       FROM orders o
       JOIN games g ON o.game_id = g.id
       JOIN packages p ON o.package_id = p.id
       JOIN users u ON o.user_id = u.id
       WHERE o.order_number = ?`,
      [orderNumber]
    );
    return rows[0] || null;
  }

  /**
   * Get user's recent orders
   */
  static async findByUserId(userId, limit = 10) {
    return query(
      `SELECT o.*, g.name as game_name, p.name as package_name
       FROM orders o
       JOIN games g ON o.game_id = g.id
       JOIN packages p ON o.package_id = p.id
       WHERE o.user_id = ?
       ORDER BY o.created_at DESC
       LIMIT ?`,
      [userId, limit]
    );
  }

  /**
   * Update order status with audit trail
   */
  static async updateStatus(orderId, newStatus, extras = {}, performedBy = 'system') {
    const currentRows = await query('SELECT status FROM orders WHERE id = ?', [orderId]);
    const oldStatus = currentRows[0]?.status;

    const updateFields = ['status = ?', 'updated_at = NOW()'];
    const values = [newStatus];

    if (newStatus === 'paid') {
      updateFields.push('payment_confirmed_at = NOW()', 'payment_confirmed_by = ?');
      values.push(extras.confirmedBy || 'admin');
    }
    if (newStatus === 'processing') {
      updateFields.push('processing_started_at = NOW()');
    }
    if (newStatus === 'success' || newStatus === 'failed') {
      updateFields.push('completed_at = NOW()');
    }
    if (extras.paymentProofUrl) {
      updateFields.push('payment_proof_url = ?');
      values.push(extras.paymentProofUrl);
    }
    if (extras.notes) {
      updateFields.push('notes = ?');
      values.push(extras.notes);
    }
    if (extras.retryIncrement) {
      updateFields.push('retry_count = retry_count + 1');
    }

    values.push(orderId);
    await query(`UPDATE orders SET ${updateFields.join(', ')} WHERE id = ?`, values);

    // Audit log
    await query(
      `INSERT INTO audit_logs (entity_type, entity_id, action, old_value, new_value, performed_by)
       VALUES ('order', ?, 'status_change', ?, ?, ?)`,
      [orderId, JSON.stringify({ status: oldStatus }), JSON.stringify({ status: newStatus, ...extras }), performedBy]
    );

    logger.info(`Order ${orderId} status: ${oldStatus} → ${newStatus}`, { performedBy });
  }

  /**
   * Get orders pending retry (failed, retry_count < max)
   */
  static async findPendingRetry(maxRetries = 3) {
    return query(
      `SELECT o.*, g.slug as game_slug, p.package_id as pkg_id
       FROM orders o
       JOIN games g ON o.game_id = g.id
       JOIN packages p ON o.package_id = p.id
       WHERE o.status = 'failed' AND o.retry_count < ?
       AND o.updated_at < DATE_SUB(NOW(), INTERVAL 5 MINUTE)`,
      [maxRetries]
    );
  }
}

module.exports = Order;
