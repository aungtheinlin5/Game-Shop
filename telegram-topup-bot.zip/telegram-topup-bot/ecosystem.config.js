// ecosystem.config.js
module.exports = {
  apps: [
    {
      name: 'topup-bot',
      script: 'src/index.js',
      instances: 1, // Single instance (bot can't run in cluster)
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'development',
      },
      env_production: {
        NODE_ENV: 'production',
      },
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
      error_file: './logs/pm2-error.log',
      out_file: './logs/pm2-out.log',
      merge_logs: true,
      // Restart if crashes more than 10 times in 30 seconds
      max_restarts: 10,
      min_uptime: '30s',
    },
  ],
};
