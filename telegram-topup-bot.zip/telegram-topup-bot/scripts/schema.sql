-- =============================================
-- TELEGRAM TOP-UP BOT - COMPLETE DATABASE SCHEMA
-- Version: 1.0.0
-- =============================================

CREATE DATABASE IF NOT EXISTS topup_bot_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE topup_bot_db;

-- =============================================
-- GAMES TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS games (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(50) NOT NULL UNIQUE,              -- e.g. 'freefire', 'pubg', 'mlbb'
  name VARCHAR(100) NOT NULL,                    -- Display name
  icon VARCHAR(10) DEFAULT '🎮',                -- Emoji icon
  uid_label VARCHAR(50) DEFAULT 'Player ID',    -- Label for UID input prompt
  uid_regex VARCHAR(200) DEFAULT NULL,           -- Validation regex for UID
  uid_example VARCHAR(100) DEFAULT NULL,         -- Example UID shown to user
  is_active TINYINT(1) DEFAULT 1,
  sort_order INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_active (is_active),
  INDEX idx_sort (sort_order)
) ENGINE=InnoDB;

-- =============================================
-- PACKAGES TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS packages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  game_id INT UNSIGNED NOT NULL,
  package_id VARCHAR(50) NOT NULL,               -- Provider's package ID
  name VARCHAR(100) NOT NULL,                    -- Display name e.g. "100 Diamonds"
  diamonds INT UNSIGNED DEFAULT 0,               -- Amount of in-game currency
  price DECIMAL(10, 2) NOT NULL,                 -- Price in local currency (MMK)
  original_price DECIMAL(10, 2) DEFAULT NULL,    -- Original price (for showing discount)
  bonus VARCHAR(50) DEFAULT NULL,                -- Bonus text e.g. "+10 bonus"
  is_active TINYINT(1) DEFAULT 1,
  sort_order INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE,
  UNIQUE KEY uq_game_package (game_id, package_id),
  INDEX idx_game_active (game_id, is_active),
  INDEX idx_sort (sort_order)
) ENGINE=InnoDB;

-- =============================================
-- USERS TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  telegram_id BIGINT NOT NULL UNIQUE,
  username VARCHAR(100) DEFAULT NULL,
  first_name VARCHAR(100) DEFAULT NULL,
  last_name VARCHAR(100) DEFAULT NULL,
  phone VARCHAR(20) DEFAULT NULL,
  is_banned TINYINT(1) DEFAULT 0,
  is_admin TINYINT(1) DEFAULT 0,
  total_orders INT UNSIGNED DEFAULT 0,
  total_spent DECIMAL(12, 2) DEFAULT 0.00,
  last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_telegram_id (telegram_id),
  INDEX idx_banned (is_banned)
) ENGINE=InnoDB;

-- =============================================
-- ORDERS TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS orders (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(20) NOT NULL UNIQUE,      -- Human-readable e.g. ORD-20241201-0001
  user_id INT UNSIGNED NOT NULL,
  game_id INT UNSIGNED NOT NULL,
  package_id INT UNSIGNED NOT NULL,
  game_uid VARCHAR(100) NOT NULL,                -- Player's game UID
  game_server VARCHAR(50) DEFAULT NULL,          -- Server (if applicable)
  amount DECIMAL(10, 2) NOT NULL,                -- Charged amount
  status ENUM(
    'pending',     -- Waiting for payment
    'paid',        -- Payment confirmed, awaiting processing
    'processing',  -- Top-up API call in progress
    'success',     -- Completed successfully
    'failed',      -- Top-up failed
    'cancelled',   -- Cancelled by user/admin
    'refunded'     -- Refunded to user
  ) DEFAULT 'pending',
  payment_proof_url VARCHAR(500) DEFAULT NULL,   -- Screenshot path
  payment_confirmed_at TIMESTAMP NULL,
  payment_confirmed_by VARCHAR(50) DEFAULT NULL, -- 'admin', 'webhook', 'auto'
  processing_started_at TIMESTAMP NULL,
  completed_at TIMESTAMP NULL,
  retry_count TINYINT UNSIGNED DEFAULT 0,
  notes TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (game_id) REFERENCES games(id),
  FOREIGN KEY (package_id) REFERENCES packages(id),
  INDEX idx_user (user_id),
  INDEX idx_status (status),
  INDEX idx_order_number (order_number),
  INDEX idx_created (created_at)
) ENGINE=InnoDB;

-- =============================================
-- TRANSACTIONS TABLE (API call log)
-- =============================================
CREATE TABLE IF NOT EXISTS transactions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  provider_transaction_id VARCHAR(100) DEFAULT NULL,
  attempt_number TINYINT UNSIGNED DEFAULT 1,
  request_payload JSON DEFAULT NULL,
  response_payload JSON DEFAULT NULL,
  status ENUM('pending', 'success', 'failed') DEFAULT 'pending',
  error_message TEXT DEFAULT NULL,
  http_status INT DEFAULT NULL,
  duration_ms INT DEFAULT NULL,                  -- API call duration
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id),
  INDEX idx_order (order_id),
  INDEX idx_provider_tx (provider_transaction_id),
  INDEX idx_status (status)
) ENGINE=InnoDB;

-- =============================================
-- AUDIT LOG TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS audit_logs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  entity_type ENUM('order', 'user', 'package', 'game') NOT NULL,
  entity_id INT UNSIGNED NOT NULL,
  action VARCHAR(50) NOT NULL,
  old_value JSON DEFAULT NULL,
  new_value JSON DEFAULT NULL,
  performed_by VARCHAR(100) DEFAULT NULL,        -- telegram_id or 'system'
  ip_address VARCHAR(45) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_entity (entity_type, entity_id),
  INDEX idx_created (created_at)
) ENGINE=InnoDB;

-- =============================================
-- SEED DATA - GAMES
-- =============================================
INSERT INTO games (slug, name, icon, uid_label, uid_regex, uid_example, sort_order) VALUES
('freefire', 'Free Fire', '🔥', 'Free Fire UID', '^[0-9]{8,12}$', '123456789', 1),
('pubgm', 'PUBG Mobile', '🎯', 'PUBG Player ID', '^[0-9]{5,12}$', '5123456789', 2),
('mlbb', 'Mobile Legends', '⚔️', 'ML User ID', '^[0-9]{6,12}$', '123456789', 3),
('valorant', 'Valorant', '💥', 'Riot ID (name#tag)', '^.{3,16}#[A-Za-z0-9]{3,5}$', 'Player#1234', 4),
('codm', 'Call of Duty Mobile', '🔫', 'COD UID', '^[0-9]{10,18}$', '1234567890123', 5);

-- =============================================
-- SEED DATA - PACKAGES (Free Fire)
-- =============================================
INSERT INTO packages (game_id, package_id, name, diamonds, price, sort_order) VALUES
(1, 'ff_100', '100 Diamonds', 100, 2500, 1),
(1, 'ff_310', '310 Diamonds', 310, 7000, 2),
(1, 'ff_520', '520 Diamonds', 520, 11500, 3),
(1, 'ff_1060', '1060 Diamonds', 1060, 22000, 4),
(1, 'ff_2180', '2180 Diamonds', 2180, 44000, 5),
(1, 'ff_5600', '5600 Diamonds', 5600, 109000, 6);

-- SEED DATA - PACKAGES (PUBG Mobile)
INSERT INTO packages (game_id, package_id, name, diamonds, price, sort_order) VALUES
(2, 'pubg_60', '60 UC', 60, 2000, 1),
(2, 'pubg_180', '180 UC', 180, 5500, 2),
(2, 'pubg_325', '325 UC', 325, 9500, 3),
(2, 'pubg_660', '660 UC', 660, 18500, 4),
(2, 'pubg_1800', '1800 UC', 1800, 49000, 5);

-- SEED DATA - PACKAGES (Mobile Legends)
INSERT INTO packages (game_id, package_id, name, diamonds, price, sort_order) VALUES
(3, 'mlbb_11', '11 Diamonds', 11, 800, 1),
(3, 'mlbb_22', '22 Diamonds', 22, 1500, 2),
(3, 'mlbb_56', '56 Diamonds', 56, 3500, 3),
(3, 'mlbb_112', '112 Diamonds', 112, 6500, 4),
(3, 'mlbb_336', '336 Diamonds', 336, 18500, 5),
(3, 'mlbb_570', '570 Diamonds', 570, 31000, 6);
